Projet 19 (C) — Rapport technique (résumé)

Objectif
- Détecter un SYN flood (attaque DDoS) à l'aide d'un modèle léger (IsolationForest) en utilisant des features temps-réel simples : débit (packets/sec, bytes/sec), entropie d'IP source/destination, et ratio SYN.

Approche
- Génération synthétique de trafic (normal + attaques) via `src/traffic_gen.py`.
- Agrégation des paquets par fenêtre temporelle (1s) -> features via `src/features.py`.
- Entraînement d'IsolationForest sur trafic normal, sauvegarde en `models/final_model.pkl`.
- Détection et sortie d'alertes JSON (une alerte par fenêtre anormale).

Résultats
- Test principal (attaque `syn_single_src`) : TPR = 100% sur la trace synthétique utilisée (détection fenêtre-par-fenêtre).
- Note : ce résultat est sur données synthétiques contrôlées. Les performances réelles dépendront du profil de trafic en production.

Limites & améliorations
- Ajouter normalisation/scalage des features (StandardScaler) pour améliorer robustesse entre environnements.
- Évaluer et ajuster `contamination` et autres hyperparamètres avec validation croisée/simulations multi-variant.
- Tester attaques `syn_many_src`, variations de débit, et traces réelles (pcap) pour estimer FPR/TPR en conditions réelles.

Livrables
- Voir `DELIVERABLES.md` pour la liste complète et instructions de reproduction.
